package com.securecapita.securecapita;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurecapitaApplicationTests {

	@Test
	void contextLoads() {
	}

}
